#ifndef CONTAINER_H
#define CONTAINER_H

template<class T>
class Container{

};

#endif // CONTAINER_H

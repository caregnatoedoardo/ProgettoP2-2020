#ifndef TIPOMOTOBOX_H
#define TIPOMOTOBOX_H

#include <QComboBox>
#include <QObject>



class TipomotoBox : public QComboBox
{

public:
    TipomotoBox(QWidget* = nullptr);
};


#endif // TIPOMOTOBOX_H

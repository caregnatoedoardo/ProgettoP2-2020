#ifndef ALIMTIPEBOX_H
#define ALIMTIPEBOX_H

#include <QComboBox>
#include <QObject>

class AlimTypeBox : public QComboBox
{
public:
    AlimTypeBox(QWidget* = nullptr);
};

#endif // ALIMTIPEBOX_H

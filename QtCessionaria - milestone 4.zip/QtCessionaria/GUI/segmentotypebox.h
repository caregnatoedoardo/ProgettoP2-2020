#ifndef SEGMENTOTIPEBOX_H
#define SEGMENTOTIPEBOX_H

#include <QComboBox>
#include <QObject>

class SegmentoTypeBox : public QComboBox
{
public:
    SegmentoTypeBox(QWidget* = nullptr);
};

#endif // SEGMENTOTIPEBOX_H
